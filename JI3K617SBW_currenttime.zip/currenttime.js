let hrs = document.getElementById("hrs");
let min = document.getElementById("min");
let sec = document.getElementById("sec");
setInterval(() => {
    let currenttime = new Date();
    hrs.textContent = (currenttime.getHours() < 10 ? "0" : "") + currenttime.getHours();
    min.textContent = (currenttime.getMinutes() < 10 ? "0" : "") + currenttime.getMinutes();
    sec.textContent = (currenttime.getSeconds() < 10 ? "0" : "") + currenttime.getSeconds();
}, 1000);